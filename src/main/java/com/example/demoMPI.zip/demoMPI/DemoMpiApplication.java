package com.example.demoMPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMpiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMpiApplication.class, args);
	}

}
