package com.example.demoMPI;

public enum Class {
    A,
    B,
    C,
    D,
    E
}
