package com.example.demoMPI;

public enum YearOfClass {
    FIRST, SECOND, THIRD, FOURTH
}
