package com.example.demoMPI;

public enum Role {
    PROFESSOR,
    STUDENT
}
